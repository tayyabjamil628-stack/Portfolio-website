## 📝 Description
Provide a brief summary of the changes introduced by this PR.

## 🛠️ Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Accessibility enhancement

## 🧪 Testing Checklist
- [ ] Verified build succeeds with `npm run build`
- [ ] Verified linter passes with `npm run lint`
- [ ] Tested responsive views across Mobile, Tablet, and Desktop viewports
- [ ] Verified WCAG 2.1 AA keyboard accessibility and screen reader support
- [ ] Tested both Light and Dark visual themes

## 📸 Screenshots (if applicable)
Add screenshots or screen recordings showing visual changes.
